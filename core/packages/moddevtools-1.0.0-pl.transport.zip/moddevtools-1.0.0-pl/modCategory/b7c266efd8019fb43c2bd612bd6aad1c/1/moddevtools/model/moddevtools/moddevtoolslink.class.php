<?php
class modDevToolsLink extends xPDOSimpleObject {}