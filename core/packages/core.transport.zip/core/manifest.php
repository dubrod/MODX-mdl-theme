<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '135123eb62ed7f4b5a73b8b841a1393e',
      'native_key' => 'core',
      'filename' => 'modNamespace/9c7844e3ac9e85e47b03bbf53ec33083.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '359839e1819391585b5181f039b3f98b',
      'native_key' => 1,
      'filename' => 'modWorkspace/46f07e631b9c3b6f71c4e50a71f7a808.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '855ec47c3c00b738e8c8012e48ec3d4f',
      'native_key' => 1,
      'filename' => 'modTransportProvider/abcaedf9627abc256521c33350b61256.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ffe45da1423057828172f8403bd09982',
      'native_key' => 'topnav',
      'filename' => 'modMenu/aa7a4ef6301141dbe84acf5912b53230.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'df9b99cb6da098490f1d9037f24cf453',
      'native_key' => 'usernav',
      'filename' => 'modMenu/2dd834cd9106fa91876a2143c0cec167.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '558bd5eff4dc28a759d16da04b92bc77',
      'native_key' => 1,
      'filename' => 'modContentType/5f88ebcacd61da2133c1e504fdd272ab.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '14e833c6cc2d2b6c77b15b249081f8e4',
      'native_key' => 2,
      'filename' => 'modContentType/d16e5b72b8d236e64c714329f076b285.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8a77ff07162e3314b616b8cd063ff1c7',
      'native_key' => 3,
      'filename' => 'modContentType/60dfde27f4d1218bb58c72ec537e1d20.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ccd68bc5aae7b851bd1cff5ad7a208e2',
      'native_key' => 4,
      'filename' => 'modContentType/d8959c5813076e77caf1e5ae470ce860.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '51904f28b6df2c835d87b99f0dca49c8',
      'native_key' => 5,
      'filename' => 'modContentType/52c54376f4a1abc593a0387265791413.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '40945fe0ee124ac2721fb06ef2f887ef',
      'native_key' => 6,
      'filename' => 'modContentType/8928a8b0c927d7d880c9636260b43f14.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b8582afd7378c3485936c710b0a491a1',
      'native_key' => 7,
      'filename' => 'modContentType/0d6e7b169209b5bfc1293f2cbf1784c0.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b1d9d2125bffab465958422045b5a89f',
      'native_key' => 8,
      'filename' => 'modContentType/706309b922eebea1b6deed9cf9d1076e.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1e7a20dee44a31df1a16366da015c5d6',
      'native_key' => NULL,
      'filename' => 'modClassMap/3904f6dc9d2473687257a15184c34ea7.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0e8d7b17a79e6c83e0ddd87ac4ee666a',
      'native_key' => NULL,
      'filename' => 'modClassMap/8d78caf833a684aa314e50ae0bef87f6.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '57628e796aa9e84966a6efb6b01dc1a4',
      'native_key' => NULL,
      'filename' => 'modClassMap/60c6d4eddccef7f2d25888992b07a2ff.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c9f2196acb4cc61528d28f3dd153c9da',
      'native_key' => NULL,
      'filename' => 'modClassMap/bbd0e30421a595d0ad349cdac986f644.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '407262b1f853315cd5c254cc74b6f2bb',
      'native_key' => NULL,
      'filename' => 'modClassMap/52461c2207dd9589a7771a94a5d1ffd6.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '64780b2735b1f564dab7dae7a87ea615',
      'native_key' => NULL,
      'filename' => 'modClassMap/060c90234eba5f13515e3c764d253133.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '08a74c659110ddb33ae152867930a485',
      'native_key' => NULL,
      'filename' => 'modClassMap/7d6cea4c7e5380d386c3a345864decc5.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7273e43b1ca4d29bc711fea23298b69a',
      'native_key' => NULL,
      'filename' => 'modClassMap/b37f8f05320ee770316cbf313d152783.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '74e6955e5ef492895266b50550c2d75a',
      'native_key' => NULL,
      'filename' => 'modClassMap/4cbd504142586c5023c52708d6a9c16a.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fa53afbed94b4307446f29a5f7b007a',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/a441325e5d5cb8872a5ca7f0e47f381a.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6837208cdb192c5a07f689acd2925f62',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/786a8c1d17031ffcb894d8096052d648.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '410d144fb9e8d68e42afd7f4d5fadfeb',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/7254c46c091879ad74760ed8bf3c9f25.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3a02f47b5be335517e8b45eb8da8e98',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/8f0e119e30ca7ae77bdece76e546d494.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9750e86c5c6b1a757087e2fe9720ff86',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/2cb1284d15e2bf4cd7dbd85802fb9c6c.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8df1b759dd08b3b5531662a1eef22e2',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/6346891e5580edca809bc4d2ee5c6f19.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf86647c865b9d2da339d39305a27505',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/d45bd59c654c3f1febcfe59f1279f1c5.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '294db3e15a3f0c735ad9ba02f6176bb5',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/d2cb6fb3f955c497c901165c26cb843e.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b6e5ed098ad2b99fc817ff1561c8ab5',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/dcbb38a9e57bb9e4388d82ebfc86cfe1.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbe915510b2cb78e402a5e68f5007930',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/f6cb1beb64602b021be58fa1c79edb37.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1de1b99c81524096bcba1be2b32000dc',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/b7af8a1d2b15a8533c1ac40520179e11.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '881ebd657db2ddc5d99e86afd9a989b7',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/39bd15df02c4df1f145df6a438461fb4.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fee1bb3691533f6330bc0172edfdb3a5',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/60bdf9c6acbff68e64b1d56f5cf99c32.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e852d4eb69d54d06dfdb3958b97204d',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/a932d8c04112c8392a689a0ffd57f342.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f16d70b2428c628fe4667ac93ed3b58c',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/9ddc1506a666b3ab39944a8fb48ad20b.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22ae720c2d227d8ba4ab15f8bf5682b6',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/8cdd2c2023ab1e436b242558d409970b.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17db2073972e48b9eb52f55a2081a0e9',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/03077beb3ece01dd36d8902e6be26cd9.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14d17d3e62b1b2e89763ed70330fd34f',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/1051722ad91a5672e22807dc1cf3a3e4.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a30e6fb27313f3824110f13648cb2da',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/9df0430ef5afb890eaa78fbc9a23e8e3.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c299fb7a84a081bde39dae8adfa18734',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/ffdedfd839f60d25dd930a060a7a04af.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06ecd2b3be1186a874c92484cbd58715',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/a7d901ecb674b7df857e9cf67c8df0d8.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c72b07f9b7ea6077530013e43f9da814',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/0e4bb857de3756fe14e7fe7172103a3f.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0481b0b0106538067900f37b3db9e512',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/7ccbbb7bd515dd43dffbd053ab30450a.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3122d43eaaddc3841a032a5336d3de09',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/f6ffe2279a70d7c45c6147b7550dcbe0.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b831534a2b17fb0923c20fdacad07643',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/4065f14da0ee4fce4ba65d2da986130f.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de1a86844ceab6c140981ea4acc328a5',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/3ef00f578af249ad3cef2ae17fdb77f2.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7f8ee00d795d65bdf07d270775aa1a1',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/e26ded0e511bf0b9ed0abc3627a88c4b.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa8d2aabc8e9f10e0af163b9c50cec07',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/a3bd4faaf3fa144aeb309a4c2248074b.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c74d418cc349a1ac487910f5e051e1a',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/22f7959360fc2b8647c78de492968ae9.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4b42f7310adeb17c0660870317c81c4',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/4cc15ea6794456edb79fe48e4ce1e0cf.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c890c4da698ffd45ceb161783bcb0daf',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/f4addddaab2c07b84ff694ab826089fc.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a67f5042b700d067f1bf84c52109be7c',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/e97b4c6dce3e29f3e16a005664aff6ed.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4306540574c19147c7e8ffe7e4a480bf',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/682ddcdb675203c3d5ba9f761302ddf6.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '351a85d034ef9b57a38e4d9eed1d650c',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/0cbb1eec99863769d28374e170a3504e.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '550e569cf1ccf312c065fe9baf64a2f8',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/021ebe44a1ddef88bb29b0a166b3d15c.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '447daede81f9cecf097d63053bc4cf87',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/845e9f737cb2e2c3c362ec4c147b68b5.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5291515a05126472d9ecc114e000c306',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/af1c8257d9d48620cae55d78b4ca7e23.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a7f0482b7158f3e91ad6019a9cf22225',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/33e75f3709d198550ae85afabad008f9.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f551f2bc42907c73952313b2ed23fbfd',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/5b7528f81a8bc04f9e5f385ff0ac7e38.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '852e0a8632d3f6a9ae5de6a2c75e2ee2',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/7878cb2e8c672cff3841d63e64745780.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b75b864de4ccf71c31bc4cd107feb0f6',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/f3c4a38c561f7d5f7b103f1b663dfe69.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e351f29a7ef7bfa85439708c235265f',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/3146184dd98113391f55457071fef2b1.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b3ce603b9b1c7faf6ec212d2959d976',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/b790a395dc66d091eea465095bb8e877.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76b060908c18d615142ba1e844a0de01',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/0bc4e79036efd1590971a0b3e19a0ac3.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2c7ffcac61d11f3d19daf38812abaab',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/38a741bfaeadc701e23757fc2bb6e35b.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '353b8ff19ebf775c27ae9d6547abd548',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/ba0340c44aee082d72f8195bb6c3e141.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19673b1171e15fcf856ec9cbe8826a9d',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/2ab5d8920d84eed22f846e1a853219e8.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9b7830a1476511e1b6a8b877b077fa0',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/80c21df296e0599b442fa9e8d8f91c40.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0afeb2822af6ebb03cd613d47441b05',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/41eb29f08946d13ec69ef347f8187473.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8fce082c1bf682d91d9345e61ad9fdc',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/b5e78826baa6b7212529adc5f42c2e12.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aac743b0d1ca3b2245af4e9e0f8c75fe',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/055c4fbd5ad35d4c97e5ad7f4256750b.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31a7e3061057c76a4b9aa2160e605ae6',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/8fd0ff0204b49226c874282a626f00c3.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '437a1b4c5a98a71a35accbe9ffd1173a',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/b91617d19061767d83732db54d0c2b1c.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccf33ca93ca843917c468b6f16357b71',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/1b19d9ab51a518b7196ea71df1d13f27.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad0ee1bd9b86e8cf834042c95c362435',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/f05f1c7b14f28482db06ff68914aacc6.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b8a798d2458627b2e915fd8e6dea74d',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/65425367256feccbccfb5a2a27d3ef10.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f192e97b9453d38b3711b10351ab887',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/316bf4e422b3aa0034548be8913443ba.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37c814b327680e796bebdd17e2722945',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/db8cd93d15f6b6e27f35b1997b968187.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '375f9adbd6327149583c8a7b08a1a681',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/3847a3e5e873d383d4742491a0196043.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b885a4e53d873827d4772447ab5db48f',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/498bb6da7d7fe9c03309d0c4565de2da.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ee2f1507e319a8790444d1c1406047e',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/4bc5941371a390024c0ba14dd936df02.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16b8f153310b53902c28a6da8dc48c75',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/8f3d4afab12e0de344e43e096407d734.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd5e3004b17be29db8aaa88bbc600745',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/6b80447ababd741769a22a6380836321.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5202dc754808bce0df8326f117374517',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/e28df484e3308c35b4efa30cbb3112e6.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd924552bbca103bfa972fbc200ccbf1e',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/2c747346b6db289bb43b220671b8ccc6.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9eb9dddf614c3a139202b119b7bf1f37',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/8d2e231eaa3833176116d17a2288bee3.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd324e3537b3e7d06055d9796b48e5fb',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/fdd096d82b799675cb5209f927ff8fe8.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f89db97e5e5d1ed71a9a3ca33e26f0e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/ac64ddf80e340943782292247e728b10.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74bb768d4c7d8145b18bec57c5e8e4cc',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/4d1de566682ba0c562d82735041bd4d6.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '547e75c7238c240598615f1267ad21f5',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/1c0d16247adc2daa4edac4859f359ecb.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e2f0c76ca29a4a1f60945b94eb67624',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/b7d7bf54776398ee9ca0b5892a16292f.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fed1ae185cdea8bcb2cc7b5520777d4',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/65badfcd6e5842d36c5ed2fac4dc3915.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bd39a929fe822b0e574d59fdce4320d',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/e816ed1216ea101a61503d0b73d044af.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '912fa1790cff443399f438273dea54bd',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/0166b8f36059d01bb173ff6a1eb1354f.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdfb9caab0fe3eef254372725ed2b71c',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/854a1377921dadd3467aa79da658a9e3.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '743b78527932c5a33c3e93d1b0908c49',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/4704a1d0f59f817f9aea34bb4844cac9.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e412fadf702708d4be1f3408c2979d7c',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/7fbbac143a93b8c29cbe376b35f866e5.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77616d5af10b25ad9db4cbed3ed275df',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/51827e2385802a97adb2f144a9efa358.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97c904ec0441a200c30730e2392ca52d',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/0ce83886ef567b830ccbcb933891b623.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a70dc043e78e425cd6008b0b587a5af',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/d45c8cc192ac6481c83aa0cb7ccdd748.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a19dd75ddf1ed26a4b1385c21bd0791',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/005f9e81d11cfd98c4ee51a7eb673484.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bfc11213c64a5ae2cf3c6a6c48d15c9',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/488737a3047566ec486878ce83707e94.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5524c39443aa09b029328be7f66b532a',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/0eece8139bb51fca9527587ec06f6961.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3fa8f442cfed0901fed9cb9ffa10ecd',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/6ed34a838cc1de1fd40ec0dee8f8d8ad.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '620b70b5a60a6353483eff40efaa74bf',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/19939fbde953b0ea1ae86c5f736e1f3b.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b9a53469185e0169d700c5a7cb16214',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/070d7535151dee5d11bb5272bb144674.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eec6c65cdf6bf0f236e07dfd507e5955',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/236b0a9231594af6cf74c2c2ecc4754f.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1704f96b71a5c9139a2ed1819f574a52',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/b4dcb3f9da34118c3bde3745017967cc.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a649a29379a3816205365c9d302179c1',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/93eeb1a315d76bafa58edce282a348b5.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'deb697084d218cee9845240d729141ad',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/f00916942e4652678d10efca61e3c510.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23c865eaac139593f93302e8bdeb0757',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/0a4f9f4757a63fd202e376cb48179d4d.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb41d954dab84f659448385d7b395728',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/b6140a664ee11097b97a25926cf66922.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9b2d9e82e40b27259dd42e9ac557bd6',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/97edb016e235ab11c86d84a0fb6c6484.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b322c784d36c9d60cdcb6292d8bdf389',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/646f01608d66c07b725566f39dccaf62.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '986c719c22df308a9392bd88f4962f0a',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/d9480a4a406056a4e6449292484452e5.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18a077ab8376ba687c5341bbb2e7ee5c',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/1bc82a850cc130d8e277c1bea6198fab.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1452dd1032937ef55cefce56f24f439c',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/5be65b41935b596fd360ac4b8ce7dd77.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6129e0b9957f05cfa6f914bfad22fe2',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/6f75e24b09503ee4142e890391ca6d23.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f302b1d27cb990535c78382806fb5008',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/dbcfdb746c3cc62a31c1ce48b43d3d77.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f30f09553de0d623a72ffab03f6c0ed0',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/3fb70a0e51f8094233227c143466662e.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a819ee5cd38bda24dc3b387276d2509',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/c88842deb75a53b736cbcc1f4f66e429.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a229f69a21cd8f59b6d6d44cd594b87e',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/daa004e4c595161b2daa4e69c489a64a.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c6d1dd165299bb20749f3d63f8fb768',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/b2203c64560a1d600c0bc070a0714091.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6902ca10e0af454d317dd6512dc7451c',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/9b72012823903afb7756a36729cac768.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2ed4e39031d5dcc5cffa37ad5fe5cb2',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/90d099d205ea079cf1276f09dfe178fd.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d8d35ee9c92ca57716c77a14b4f9a4f',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/7ffb5f9ced69ea7b6b184de201858d06.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9d24674802abc43a6e3359772dd19cd',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/2e3e3ee67765d82873cfb28df127867a.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3aec8b28612a12e58ae4e199ccb0aa80',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/672c0f09811f3cd062b9322d87c42ce5.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae657fac2e58df9d94237fa88e720b7b',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/9ab30931f407942893a2ca413126e4bd.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e14adfb93a752ea3b3cb1b40cd40569',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/7a1be675d0f63060a557d713a0818f97.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af9cb6ec41573215728b7022e485b0ab',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/b7c639ccc16fa9bb74de0899244a99fd.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef8fb1cf919073ef6296ce11212d0305',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/fda823ceb096b4a6839e361683fe5074.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47aff1695c7e848ba218c94adb077d75',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/013db7466ef804989d1174b5670d1e1b.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf7ba117345ac1ffc548ba94d1b48086',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/09b5074c45f49f57f34f0ec65ffed77d.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5035c47964a467d42919e7db7961bd3b',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/625d69fcf05b52ed050e6f320c6ccc5c.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3511569adf21c6773292197cab66e0aa',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/359519de2ef79a889525f9a0bc7dd642.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c40e287386d0ff14779b99755d61635',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/eee38c13c6e6d122e1c4965ffda31437.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '301b7e0d524c886348df1ff1c175543a',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/03804df85ba9eeb61ef3c84584922428.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21f81bc1cdd7a746cece40512f4402b5',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/b81655ed6c0e4769979a77e78ed954f3.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39f1fa869b462c51840c92343990bec4',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/e5582e549db5154453ff73838da9d778.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67b264e7619cc457c2d7b363790b63ce',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/f987b43bbdb58c455155e3dc701edf3f.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c309c7e1bbdc77122f95cc11603afb54',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/b26ed0964f68527ddee365caddd56cce.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf59b58ec94f29744cb966b7f640cad7',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/480ae3af8e2853d40522b0971a6c0c6b.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eabda8e90d39c06d4a45913fb9853068',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/78c4a77509c23aeeddf23ba5ef1e55ff.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '007895930d096e607ea29cd977dabed6',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/a4c7f45b69ac1ac27c1bd50be4dc4900.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8bae9bf1d77c34cb24b3e0c3ae55a6a',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/fe36404a7090899c18fcefa65ed5af9c.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd16e0a28a4b37d87cf8b42908a5d8ad0',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/232d6420b6c94f5e515750207e6a6c9f.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50f4e8418d541a1556d1b39b477f5fb7',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/9a7da8861a38d71e90e319f6c4b109a3.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '985b06d3b6be52cab7ce0702903b3c90',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/3421de104cbba082771febf4695dfbd7.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30b008bf19a558af56e82846f656b9e9',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/230b639faec5dc738945b9acdfa7487b.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4a5828980f5e7c12a6e8662a2021729',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/def52db4cbb1bdf6c890ec1168295cef.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa6ec980daeae07a8b86ba73e06e6e60',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/b1ca66fbdbf4637b41eee5bf65ebfc6f.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7a144748e2852c3b406eb72e824475a',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/adbcf17c33ef8071c507884de5d00835.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6823eebe68482fe40746cecf1d3fe56',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/76dc26ecad82fa76b50405d6b2e526c1.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '428bfde0533e74865cdf15f5cfc7ff89',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/b11d60c5cbd9c29aeb33ec7d70d76042.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4b73fc9e348cd4aca2193352aeb1083',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/7dabe2af1a2d0fc458ea6e722a9a89bf.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5dde4882f31fe0bccfa1c696928941d',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/2984b4d0fc94995f7c1ca4d8878bfcbc.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f036a81b969c2aa1db9e03bbea3d0d1',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/091aaeea76d5030943b125d9d5fd174a.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88d8e16d6b7d587fe62560210700c562',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/c6c53fc26a5efa16045a5544189906d0.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e688c09ad4ddf9d2bec4103391f61300',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/3576e3df2e01dfc22557df957f39dc42.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61e359e6e3e1d8c119dcde1e6b24896d',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/3614695266d434ead1c0a593d8194ab4.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'adf95864b6be21d07f896998d8575b6b',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/c0b794f583b5a1ab0edb9852c638e7f0.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0d89ab812d22508a0568b996575b5af',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/b39fd8ab464a85c5de8962948a7666c2.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff9145ec462ad746d71122cc8d7f7f77',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/57d045e9e212c0e344d1b747aba93ee0.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ea3c78862d26c8aa250cea6411804cc',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/9e24264bc2203486cea657725a790dca.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c3f0a95856441dcecce6984bbd01ccc',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/184ef2fd3eb4077b5445f0c2ca1c7f5f.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33ced09ab2710db4354b88d2cfbe4cba',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/d1355fa24995866254c5f2f44c670ce8.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '295dcc02df1e14fedc9a7f57cda4ab45',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/bd72362f4d451671a864529c7058fa2d.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '866f0aae6399c568f4aba3c0b7e50900',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/a5acd773c4db53387a10663fb47ec494.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '096d466a0054a7a599209e90b6907723',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/a102c3b79bca6a8290a532ce6f087a5c.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '936d416f937c82815bc2730e8924cb9b',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/e314bb3fc128ac39a93f4c1bbb4f938e.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75e9e77425fa801dde16f649db6b01cd',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/69b8a00b15116a5daaa971d45b1b56d6.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98880729acefeac59f684972f95b2749',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/f165f8e42b0b47bea7582d4c3f826008.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0508154a17a93fdbe42b706ed3489ac4',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/23c3395ec5abaca0b673e3909426a6d0.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52c65cdf3c292498f3adebc59d8f9ba3',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/cb8f4f2fb087280d038bc42f72fde9b2.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1dc0bd1c4425a370f829289debed718',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/63b1089d9901f082dcc82c47c2c793a3.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65bca6c0ef7b5e784099a8a1c50d9281',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/37f1e39f0dc6a24ec2e9541ec30daaa5.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1b05193638b44487b9c690b8e536c7d',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/c6400a4430aaacc8d21dfc5579de1931.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e22f561411af026d27b00330b34dfb08',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/e2661a94b53b8888d5af0b05bb2ee3b2.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ceb22febe8db55305001a764ed61dfaf',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/418c78839b738b860ad8953fbcf24e54.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4dcf14a3a60107abba358e660e19568',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/a69c3278b982a2c88ff30dbc6ed43279.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fcf58bc79b3f65926eafc1c6ae8abe9',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/5ddb809a508a7fb99c9bf916706b513e.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b163e3007968d6d8a17eb47dc40dfba',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/7a4030ce78a92af6cb107e6a47fce168.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d4bc2b435185191a78727826f9d75c6',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/e0838758d068035a905a64555baa63e1.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc793b8946005366820b82532dab842b',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/aa97bdc737a17d53cc4978cf15491f2b.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c64f61bd3ebbd8d7174f23ccde18832',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/482fea2b31a0300c55f0ebdcf7acce04.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd92d7681b94665beb373b93b0e823f4c',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/ed652320d1a06a3340ca6dbe363f1299.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '597187bec7654da26bcd48c337e6c446',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/3b162880108fd2d027c770874890e616.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd31082e955c85f7a4cdda32e8687a1b',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/654ed835d29e2f83a5696921bee58864.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b12dd1803c583ca52a21e929af43cd35',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/79061a6a07fc148d034d9df133ff09ea.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8133939d81ffb6963d015e34a61fbed',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/f0694698bb6976fa40464eebb2d5bc9e.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23c84e4ca1d778f94c2029edb1bf6fc2',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/9495e30d486122e7fc5bd65fb08649f4.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '386eb4d2a63c42d48758adf663241664',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/84d52b3f6fb19a4521c1fb8880fc966e.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d594f0249293261bcc07b6d8f1f6b00',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/76464338e067ba4472664813e4628d4a.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41aec6f0e265c012ffe03b2d651c4ae2',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/374f9687341784265792527475cd8703.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16a643fa188720881f04ca8cd53d747d',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/08537d3e84b0c754951447e02732ab77.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'badfe32697d21313c47750cd0d3bdc01',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/3bdac8ea2e73d72d04c5649546e6a850.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3795f6f28e97368e1fb7b0e015a0de33',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/1386b46200e146986174430df12e497f.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12eb28ac4c026836372f13198a88a0ed',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/84f5b30c01973f4a6c581ea959605fe4.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9e0b2e7dc91649f987ebf6b1a2f62f6',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/b3cc0b7954427a91279df87d970d48dd.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31d694ca4048ac455368bcc19f60257d',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/3c9b99e76b0622b21cb3a74a14b0a365.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27b6888678e55bd58d78e91132c47080',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/d74a4880b37f25a5852c238d9b5c8700.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9694c41aa486a4de397d9f2eba5c574f',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/dfe7dcc713df4ae8c1ab4e248d75e3db.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2865163d3ef4f919720894ed3544cb2',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/7a16c5da72b46e53e24963e4c2315565.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ce2f8d9307d9fea4934a0961354bc65',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/f540e8de1b20b16be013a64340491304.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f105c3431e63411b69f1dac5434527f0',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/41028fac8a77ba68d757ae851a787743.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cad6fba9ab9e94df610224ed72f858d6',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/7607aafbbb4759562026a53406a6f5e2.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b9f686de4840d3d9fb3054957186c03',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/9a72ab9b7f04a7df09e3ce37fba15468.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f753106c2ba5f5cbff3324d527b94079',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/a67407e8f2bef54539f93dcad37afb54.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e21a4757aa42b18335dc07a3ec28652',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/f7435de72ce8b0733d5891cba3736216.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b074c0e130437e787535bf93568e858',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/85d52059676fec87489e42ab0d77b33d.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b057e85c9064df4025be412a9a74cc93',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/b62b0ee440dfc3c6d5cecdaa651681a5.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0abc9a285c02c0596be1bbd246a892bf',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/1e975d8493c91f24bf73998e43cc144b.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75c4a2da432d8aaecf99908ea8777863',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/d7770f25ee9ed52e9d507082eb060248.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a0ed69f1ff7fe5ba63710e2466e9f00',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/83ca53a55b20c55c2f9ccea8920a1cae.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1877a1c13fa19cbcfd89e6e8742f170',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/c1fe833f59be814cca07dec113aac35a.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c07b38461cec7225e5a32189bddb940d',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/5739bb78f005e5550fcecb57a2fa7fc7.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed00bc3819944859f8781b4e8c0640eb',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/d5c9748b190afae08484f2a1c170bcdb.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62b4d5d74e5f7ec846f0b8b417cfa767',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/313514e1d10b9c372452e166c8ff375d.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'febd3f562826af9c343637cfbf7ec105',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/0a0cd18ad223dc77fa3f9bbfd6804f05.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b8141c3708e881e018765b2d86a9c54',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/cc232790ba837d14e22e6ded8730902c.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f22d18c500c2aeba1d73f634169fea8a',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/343e8f6309aa58788566aaceb8ed8b40.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '392f85c1882ce437135c69a02a470ae9',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/4050bdded43a0d6fbb975be83418d2c6.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f13d610354868df82f34992203e35ead',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/7cad2d5cb85bf54d0bdfe5a1d9ed12f7.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fa83631f59bb3bc18e7a947309b9ae5',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/fd395c81776458dd17353d542091e62b.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbe6b6d8472d8174a3bec1a115bcb6d3',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/e4ce9e8e556dc4ba5d4ce09e8cd93c70.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd03b91591d0eb64dc96265c7b0416174',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/993f469ca80eaa46306f40a0310dd419.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf7c8e7e96c20c61dcda1290d719c99f',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/5c5451bab288583d5e5b0851736bafd7.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83bd511d485aa7a24308315eab393f10',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/134a468e00a0f57d2ab205e0d688ca47.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '052ee7eaac2d2b8b5c43f8da7c93b5d2',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/adea0dfdf77424be1e9a82112c9641ea.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27abf1c1e018a718152f926ccb33b852',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/be74434fd3be78dc514abf5b4e09e4d6.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5041a018a0b31178643dafc1f9be6f5',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/03028e639a71153c3641abcf8abb3db6.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f768ffc8f3331fef2c675522f23a0fc1',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/a0e00c713f450b38f6a92e4fd9b19ea4.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46511497ec118b1dc134f4b3ac9b6355',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/3c0d33ae765bf8e5f5cc3380f8747a46.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '469d7f31c80a6cf1dbc28018cb99c170',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/8614ec675c30962dff2e9c814ab76762.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2946e36c0377e965496ece82ad6b571b',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/965c93e2b468e1eb694d88e5e42ae913.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbba39fb455f3d404d73e3c5286b0a97',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/ec69cdfc766edd7f7c20764b90f5c0b1.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca9dbf8e8690acf5a8ff35fce9bf0d6b',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/84f3cf1900a4acbcbbbd65564b45bf35.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8ac3cf45746ecc350126ed255291252',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/d85f02326c1400ddc5255b1a9359ab6d.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5efd00033810aa9c50384d75c5e1de0a',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/d75c20d9ee11bfe8ecaeb23860394f3d.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e38916c45a9cc1d97f0285a81b704b1',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/1a02a6977c446d2c0ca61e5ac2f54f6a.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7729406c2fb8c3f6aabda0e87cd7c6cc',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/ff74bfef81be2d67b63730f810fb417a.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13f903c2f3eaba151ffd4ef4d5cc94d4',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/959f5f6a3e511dd6bd5be22e99d81aa8.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01b7dc3ab59aa32e4caa32cc7e189701',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/2ce7d99096220a84bc4c8dda0b14aa76.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dacb0496286147f0cac0c4fda5798b59',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/dc79965ece73afbccd8fe6c4437a9099.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7080dd2e63fee3296025eada6d6e017',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/c34ba5b3842c34023dd1af8f70df1371.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4c91dc0a31ea792532b49659b85e007',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/367a2ddbd32d560129a7fdd6ae830d81.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ac37ef40cbaee7b3c122f6a1594f635',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/c823951cef95c1bf58838d0fc963a119.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e66d8dca7e3637575b941c62492171d',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/2397f5b001e622e7d05bd6466cc262df.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b3f04bd9f1e00cda4cb74b4d9fce26a',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/cd9718e662c88b037d873597707da613.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c0d30ab5ff9c914ccd524444c51c287',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/ed78e62bdbe7ff619b5b861c995c18be.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '782fb6a61c9183b1be5370b28dec46b2',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/88638c393f02e3d723cfc2fe3441c11c.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9478e63ceb4de736f9ea1ef200537615',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/aaefeca3a887f8dbe41d6b226b397776.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b77959a160410e36daf21907186fed64',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/48903d71d717764299a372d7c7087776.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c93c0ed2154a860e5382a4e28ee9bf3c',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/19f3a332e77e24c5d83b86860d83908e.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f9ed6cb350319c3e3063d3baeec9b6b',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/7e550bfbfc8e2e4eb852ad2a43f295f4.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee193e977ab7420d7d8826fbbb74e8ad',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/e78af85a6d20e902241d87d9316e3884.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71b731b4260968ce13332dc999251851',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/3aa989f182626650ec5a83d12c17c510.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90a5af791a22d8cf57a70dada8029164',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/19a2795b1192f56cae7e712312f1097b.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17d658ad77114134f09f9306395454f6',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/cc4756e25aeff71db4a2111b54dd53e0.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ab72625d31c2ce16184b0d77ba3f0f0',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/17c743ca4540490f4f301b08adca7f21.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a7d34a34f951578278b9336aec2bb27',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/420685617600669da99ed918bb92ce1b.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed929ba48cf89b772f86051688cc61a5',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/13bb3d7fccc16221edc90f3c762fc01a.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a829318382961b970d8ded663267f652',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/99dd416ca11272c8c40bec9ea44fcb25.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dab716f05730059a9b40fee15d24a036',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/1ba3d6d01f81415a8695e9296358ef6c.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0270dc93f313e0be014ca4882fb8aaf2',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/b919cc85afa9200111302f54e2d2d4f3.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fd5787eecef5c76a4bccf2601fe6d18',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/9985fb9d7836ffb1293675cc4965be70.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fb0a2a6c40d07bbd403748cfb92ab79',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/b2e0fd24dd5a86d3d513578a20ce0bbb.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c859785d8f598f58de0ba3e9d860b73',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/c06cf8e4536f104540d5896d7a82621d.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '097f3489cab4b4c8af481c3f690019c4',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/ee650eebeb89faef7c3c3bb043bb1681.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be8ec18aa52c864e38b4b19562e3ee95',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/4740f78a9282f531aa54fde267e7eeac.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6239d4b5f694ec02b6291b7ed91e693',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/8a114e6147e660c1ccaad9184746de09.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfcbf1896cafe868f60ca4f8878b91e6',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/ab7a13ecd958a84c7fbcc230589a8c02.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1699693b236a43e4be2cd5ffa3bb1ffa',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/d1a362b4e9bdd4ab1cb087942ef04036.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a37926a7740d7d30c2cbe8e4fc4114ff',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/dd752989b635975f7a16dad05c1424ff.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd77c97cc86298fdd5f07f57ed4ee2c4',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/d7928e5abe9fb4f0c127e7b630637be5.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd90622ea75dd248303be6c675cbf76d8',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/ebc0095bb98e61f654921463ae5430ca.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fa08dac2574ef7e5749afe1114d6bfa',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/31402629c3f345ef5afe60525c20fe38.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db589b4512b5567a5e1bf239cfa1bb21',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/6de336c15100cb963a3ba59aa67d56a6.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '123325e007c903eac53a5d5945a11c62',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/896ce636c794d73a709849d89fd64a08.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5eb1029ed6f2d21d07047376a3905aa',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/716b97cbb403b4c89bcdd4cb7fc1c0be.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f9c1e4a3da22067d0e2bb6758c85511',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/ad5e8ce3ec577f411ca75ef9b3f10aba.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23883d73895eac138a9134eb6ef691ee',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/5ef226b6cf0aaea6207989dc775ee8b7.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0290a32088c7fc5b5dd23e1e7f3469f',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/ab4fab452be2c26132c2531091a0f7b2.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ed7d814e92ee3550f5296b629cbedea',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/8d9baf156fa1e5858cb6c1c510847351.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8de5d2e306a7b9204037e25c8edc837',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/495a1fe6b94cee9d297b9ef7ca7edc57.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8646034f02270d3c6437bfd2633f729',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/0d76a2d61f797a5376c69d86b45f208c.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ce29da5dea546a4eaed5b2706efbeda',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/9a217081851249f3bf5e9b8551671041.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d2a6cb9c05447ba0b7f2f68adb7322e',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/df21ac04e59f9975b22370c0fd006b20.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3704cf68ef2c17ea7a4d107a2c7ab9e7',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/ba89be9d64ba746c3b0e1f6c2bbad651.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '898dfbb5dbd4f5a9bbb75a7fbc0dba4e',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/251f461be0f4783ae96d104764e328d4.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf8f2389d65ae4ac675dace684280a01',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/7e399b60b41970e79491090002df28af.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32a2a8281211382516b8151f730928dd',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/2d159fee68a4fa020fdaa43064d43325.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5eb50e76e106a92de357eaa9801161b',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/fca401d2862e9787e289287685d4036d.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d4051986f6deb44922ae5d49f2ab53f',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/003acc988a5d933516abf27ec64083e3.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c565ca43fab2951f75b0f9cf0960a856',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/b87da8bb441a219bd9d251c17ba21eb3.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd95bd43a7b23c2e1af956b3c3390aef7',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/18f8ed08298f012d9eda99b6a63b6e43.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cd5a3dc64cce1d88b40f0da30b48d6c',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/82629523d41c5ff7aa975ff4a87ad910.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc04b2af71ff232f61268b542798bfe9',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/60f3a60f5b2feb44f3975cba637f05a7.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8005099d689229da9232c12117259dd5',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/fcf5ef091eb88904702b3a0d3bed3cf0.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2867510bcb3c89e0946953708321a7b',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/df8292c4331cb9006948cc24fd76f9ab.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e00715a9fdeff890240eaee748a7dcb9',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/89ad810bdaa3ef9a88cd8d0792d9ac75.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec2bedf67e2a046526ffe04625f7546c',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/7ce1434921190d9f3e7f326bbdc17df3.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f8b3f8edd5b377a98f1ebdc734f7c06',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/524cebe417da5b6204fa2fc676d04638.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b09ab4a5506745d52391e2034d8b56a6',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/f3bc9326ac806ff73535ddad422f83b3.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc55939459568160969d562ff5e322cf',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/7b0b61fc1e60dd365ff80a5146e10881.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '519da5a551428520b54bb880ea58e984',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/27ca4cd73f07e2e03fef4590fb52e819.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bd0b500447d575f04934ea9d057d106',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/b487f299b1f7eaa8d7a9601bf81c38c0.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37af4ec6d12af32a49448dad9125b865',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/535a07b424d545c2243a5bfb082fcd2a.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c2c43036d3903e7545a88a70956948b',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/6f03c3b717ea56de7f2ed26525269f09.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '169ff31878bcff29057e41cea984c52c',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/32b7e24e8d8b80950f8316d3b34ab9d5.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57cb1c70907901bc3bcb3d6b16b75fee',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/ad5af2f8e7b38bb9a52f3adeee7ebf56.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '161af47d812b7ec59b3e39fca058a9ed',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/31f08cdea4f308de62264105adc7b0aa.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f0dc08a7a861b2e4f3d84139696f41f',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/3c8f26dd3a2c6b204e776ee2e4b5720e.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4581f98baa333d4f0d1414b9dac3fc04',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/6aac14fbc4f114b69f79e7a58089ac72.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3c801a6ddd8edaa2f019c41fa226476',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/bb3a22cb87ba0e338615579766caa45d.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f636bf1ef348b5f2b881475f5bab9338',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/c35e8884808e7ef5c96d92874bf4cc73.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '911f83a9dd4406d15fd269b2d8975ca3',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/3ae0109734651bc2a35204e4f1e80e91.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7c1983b5b8a542f7738ab339927c83b',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/e9788d69be0b4df0eeced17009ebbf97.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ed4a1d475e6bf583903e09bf8cfa490',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/6c9ba3e165c3c1b14c5b33aeafcd789e.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfd412cd479c414675754a86e568a73b',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/e5925f225b9109f30cec1818e1010a83.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '981914044d9cc06cccd5b0d2b41ef909',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/90717001a160da9e0c416d7ca0139051.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f10dbdbc35c2946a2c2237a4cd1958ef',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/a07e7c132028a6c93aa6dc5b9b5fe643.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ecdd49269678772c4ebbd2f13a79148',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/57dcecbde71ec402ee546d5dc79954bb.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13092bd6cfa9749cfb47a9f6db685e6d',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/ba089a6bf19559a441ae7101e060fe71.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa783df5646b5874776a20a84f21bc8d',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/099273cb404367affccb9154b0c182fe.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b39c466848d29a578fe4773cc5da2b9',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/6124eeeb101ffd58578a998c89e25269.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '680875614b2715891fae642d76040df0',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/f5c7e837f982bae538e1cd11ff802042.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2f6128760c2f0b7f20044a075d3b21b',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/36c7c54c438de4d2f48eaf871c38ef62.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '022215dcd24ded92c7c3dfcff5d7ba33',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/2bee829a50b92f8f30f6747ea5cdcd1c.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6a1015826df5738132b9dc491cd06a0',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/1bd90ce80e45708cc2b4abfd0d2aecf6.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed710c4c5cc2a1b8fd33e11e6b11f470',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/d7e61733d9fddb080a364492cb44260d.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd1386d172d8f43bee01cb98b3111d4b',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/0bdb9239831b13de2b78517925836ad9.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02c28febccfc1b03848840a501be1a00',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/55aad622b9aa0c256c5fe73a35f0b502.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6438b54a4c3cfdc11479c17c24ecf451',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/fd3e5bd47dc09bba82d4c4394620166f.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d146f94cb923d951858f3a07dc95e89',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/461c0f4762d47a8e23fc901f9a30766d.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90848bd6e11dc03ec3792b28423cd253',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/7ee57deca06504e168ace287ea119c2b.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a015834663fff97db7efd56e0f19966',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/94f7b4c523540a7a1471880a319bcb81.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e7d8c11d8978b463fed7ff747d64c93',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/6d4fb0283181b6916d5f122fda749a8f.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c69d84c59a93d03bd996877124d3d8aa',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/1c80405db989e60ab5837f9ef28b080d.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b20489d3a67ceb25bcb04a7299df3739',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/5db30d11ce080071229a2e8a93ab8d39.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83f19581b4383b139d071e3c83a1eb77',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/511fa84bd636fece1c6a2ab568c5403e.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba8a63f52fce7dbfe9f4946e7933e8cc',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/580d01491dbf066f378005328fc5a1c7.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f4da17c0eef997580e3f01ac0ea63e3',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/6e9cc33c85bf449b3f588fb397ceddfc.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e72ad37a21ee55f3b3affe431868979',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/2c5cdd3bb66ddccc4aa318bc79afe9ca.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9182e125da0c1119b34716ac206e8af1',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/8f8ef3c72291d639dccf59e9b5142917.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb76be03e77b2816aa17ff640816b085',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/2c0ede3883c352749e4714793dc2c06d.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08f58b19edc04c0ac21ba610a73ead50',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/fb61e396b2c400e8d4e241a360eaa100.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a52fdecf5a04e89b2b19ba931030fa7b',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/2e62e1d177cd557043df3d65f1524244.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe25e97955a3f6edb5a34045f0484eff',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/beda213b3df6deacf0d816c3addae950.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6606cee6fd614fb59a166dfc2d165a5',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/a033c632f91b759c05bbf782f9322343.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9ac79e795b977729ed17f986df6ebaf',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/6c3ba8d3f330cf5e3ecbaa3078a6975d.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7c1e497e07efa285be8c06afdfb457a',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/2e02b898541e02c5232ceca686cfca5e.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc3a14d0740b4cbcbef0c8ab51f1ba67',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/761afc8f74fb492b9f588a8096843843.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0264ce4cb1e9250c67668c808b57fa0',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/0b0c2ce8d4b6e0d91f12b04d27421397.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '484bc9dc5c65efbca03f0c28074066c9',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/6ac629c4d1ceba91191d7309cbd48153.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10aa9db8c2999b0b784904f9f9fef454',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/bb75eea1be6d62b981c08b67a88822ab.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7967f706a0ae1489b010e164c5c0db71',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/87e025de54b80cdea2e59fbfcff56508.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5759009918b3ab87716f0f4e0b726757',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/4fd2cc0d826db47d8a4e8ed2d97cf7de.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4fe7494e60f48a0aa67408286bd1ec0',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/4289fb70ebb455a8a948d373fdf76b43.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c85a0a91a620d22d2980da970865e0ab',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/0bbd21a931646abbf32121175de442ae.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19f0ede48cb1962933dd48a493577702',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/14442ac86dc59fe810b7b86732c9ac33.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '213ffc00cd0aacd7c956ece13e2ac13c',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/ceb769ad924961176d3ec67d3c2070c3.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a14cb2f2d784e4cd986fdeb70e1f6871',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/5290021ffad74a3f8cf04e500a5ebdf6.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad4d0f5b11bb396d98cac9233b88f18f',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/7d44793ffc2feba30c873eda507e83b6.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d3a51a99ec78fda9433c856a06930f7',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/78df993baf500f0a0e02fc1009bee4a5.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04c3ed69a3ffb1a8ac21f81f1a142a51',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/5b70813504b5cb9a421443e27019d437.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37dc87c15a5ce334a2e10f7ec6be4813',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/304ee463b01fb68604433f7c99f643ea.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdbffd2c7f3b02ea9f075e5fcb5d14f7',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/02c05d765a23166d233ae1a7071bb598.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f04f1558c0d14704a543cdd5457a6a96',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/2b4698bcdf37939f535e52ec3c55b856.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bac60dd5286b35e43999c9a31e7915b5',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/8b37efac80454bea948a86083a4a47e9.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1140fb9afab2ef4b3fd4515a276ba75e',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/7afd860288402d620ec28f77467b4e21.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddfc0c4deb291c9e3f9ab8c505943130',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/3a3ae4ed3f7005a0011bfce1365d488e.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a4aedb6a5db1113a06c765c3a3ff5bc',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/d28864201ccc5193e5aac5a881b4147e.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a13bc8a133d5976cd1801f4fb9420543',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/94f2095599a8f353e6ce756411d9dded.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ef421a9a4af90c34a604e57a41537f9',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/eff742e729820eab444eef4fc5568346.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd3baacedc96b1010b196654290e3b32',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/c4e41e5313a7557072af2e720ceb7f95.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23ff67a777568466df7fdcc55dabddbd',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/2026ed94b78cb6b774c37f52ef677ec9.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44d023d192afff0b3abff2a721a50ab2',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/a7dd26a28fa7841fd6257a32102eb4a5.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01e460fb69bcf6269dc882bdeaa299f2',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/c921502e95d59a614a0a5bf20f39a897.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd129501412044175c00c714d79fdb540',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/cbf77fcf9ab075200fdfa7dfe2dd12a6.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3ba307c9c3153ddabf3c3f6c3bf7aea',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/a14a6211c048a15095ab6e558fd8fd6c.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e38863b1fd9ebea79e7010cfedad770f',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/95bcc5bef1aa96681ce93e69a27a1635.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f09efa8e802784d5edc278848a27dd21',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/64007f87c28a3e37a9bc47253e4f3429.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd06995ae5504cd757753247fa1faa9bb',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/bcb70b71d1f186cd42f7a05320772853.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7179f64d5c6be3be06c437aad75fbc3a',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/69427e60cb9f7e31b52a1918bbe5f86a.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5ec84f7312049c96ed27bf02ca2d8d9',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/f51fffa371cf30d46c11b6722b77f783.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3eb87a77861873cfe6a787726dca1be0',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/7ba4a877fcb0a8782a49d65d26a08b3b.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4085a8bc9d7dba3a0291e9810146152',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/89d38fc3ff44f471d3a3cede5d143fe3.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad9f21e158bc02ec84e02104fdeab818',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/a23fb19092a23fa3471642214b45a276.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '920a738c4762857c92194722b9518f36',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/d5c7a4de641a9701801b0529c7cbc26c.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2b660fb3c534883b4d3abbdc175f5eb',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/4ce0d7094fa5aa62cedce5234723cf25.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09fcb7fe9f80c3079505bc78851f4522',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/abd46095b3426174fd3e6f456276bc31.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a83cd8c8dec3c6524ce3ac038cfbef65',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/acc2c4a491e990009d85831780c98bfe.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d3f22db8fb1e8a69917ce6e2da225eb',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/a1916f7c562c6f11f1f8eb073349cfca.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '202c62731f3cddba5813d946e7dda643',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/f3fdaa03aaeddea9ba73523605679a4c.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fab97d2ead8d406de27391c7a756b664',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/565067fceeff1020f087a1556cad6f94.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b38b3b72f5da6558b49d64ed9334c42',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/23d9c1a8373037dd10796f932f68019b.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a73aa7e1c15c12c16269d18346b2a7f4',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/a9c34621336d65042eec6e4f80aa8f91.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb7ec2b481826a131287971146f3fac3',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/4e48ec183321645c0f6b9475edcf4aeb.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b24b6d88572695b583b1addefe653c9',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/38692a7df875f9a5dd6e56045407d1c5.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '613e4a07711fe900645051c12ec6bbda',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/e8fb88d51b3fe62488d9afa8b92f99f8.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f65cc1872a49240c3e4e1dc1ae630163',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/400b9d912a33952031c4ae6ed75dd68f.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c57945f978aea28960825efcbfbc4480',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/736d9ce2ec7969efbf3dced99ee467e4.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a407104f22420b44a1f6feaf265f8e3d',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/ffa2aa8f396e4e9fdfaa4dc0f7ebe8a0.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c0c41411a46a18d5b67257a49b20aa1',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/c69d6a2ff82d847c2dda9b974a2f859d.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bba1cec283dbed4d08cfa4b5498fab2',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/6aad0d132aba52781d4f18f35b2c8d7d.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99b4daa0878ecdce3e2e9b289e3cd8c8',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/f55b959346667f714a451ce9258907ac.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c22c01d7e578c5caf5df9b5dac09439',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/5a3a3a57d7f008ec44b32770f9bd537d.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecdc4595f368aa74f5c07153484dd135',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/3658524a4262a4d741600a11eccea879.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f543c0655faafad7084fca9e936a1870',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/3045e11be519d12dbcfd1adb7cdacf96.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69e027e8484df66baac2e533d832e99d',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/f187ed4e9c7186ba0fcdae2c01b4ae18.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '069d01fc4c2e4be8589bf23b180da096',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/18578a9e7586f62a56e554cc7393bafd.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a66b5a2709883993e74a946619b386d',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/3dd13bfce239fb44ab3fb74951db90d0.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36baae98a8dea9be4f1f0d31596bc32b',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/8b0039ef063d4b5495de453c1f7de405.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc669344859f3207d2b26b50b14a5f63',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/edbe63a689fce042c47e3d89484e1736.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08755bbab6082659060fd0554262676e',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/85dac33d1a61ecf12ad34659dc37c666.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0f849bd7f37ef55907169f02c8cbf3a',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/2770d7a3192eb1e6a7a0a7e0a76e3e1e.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '502b5298bbe5833cc6fb95f0653d29e7',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/480161ec8d53cb0e5a06ed573e632b0a.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dd7b066db78a2be0195d93324eceb20',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/b640182f65becd79b8f42a8878c9e054.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c70afbb82fd705ca32b0228028b4ced5',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/e4940d69eddeab572c10653d7df45a11.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6125de51302ca066f660400d148709ae',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/fb5c5c3841febf330b5f89e6d92808f9.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c0dc2b34e6a61d30dce7ef28fde9658',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/6a9849fabd678ecb9a4b9cbb504d624e.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '6d4f999842bd81e41eb5029940dfc61e',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/c65fe393c45018a1e43e9bd4a1bc1d9f.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'bc842a6857c109f7b75f4b84aeb50681',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/d195dcf85d51df0d3a04d51782353369.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '42db8ac150813b5c181e3ac92633cdca',
      'native_key' => 1,
      'filename' => 'modUserGroup/6211b73e2436accf1bf846becf841e25.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'db31d832dc52f276dd8b009620dab6c9',
      'native_key' => 1,
      'filename' => 'modDashboard/ac926344c5c9c709b5bd72ef00e73e0e.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'be823537dcc738112546480794d87d90',
      'native_key' => 1,
      'filename' => 'modMediaSource/872da4cd80b1cffee0b153a9427988d9.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ad76191e7d1a8ae6dd5dbb162c954edc',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/76d98416094089971f3134e3f5bddae0.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f341d8f176dbab5e9d43a52422da9c72',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/f1182d41a3826145790939b33897853a.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e91be0ded7e29e6c36cfe1cfc9929dca',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/dc3d123bd8a41223ad537e7d66dfb929.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8c421f78a8f81f72ea03747e71edbf95',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/8bac116843b192e55d1d9a5cc085eb01.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd64912d77298bc3359e843dec5ff5ffd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d01d98fa1bd8253059665b8adb9f2a69.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '22a52c7edfba0ad83f2ae3a8c45a042a',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/5b19212dab3862aa752cf988670b3309.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'e4d27d1552aab919a66e8b22a5cc7551',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/ed2e5817d3f6a9dfb4ed9fa7f9b9f56e.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'fc2c0aa188c532763c5fd97c7ae636e2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1dff9d825a215416f1d060ead68d7d92.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0f025cd47295a3419053b34a10647a73',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a4ebd49c78fb04ed782ed3f20a638d44.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '09e3d2352597bd66d0eee2aa3af990f7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f06fee802cce1a74df584626255d9f61.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'f441c0a067fa3511a135962570a8446d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2a050d6da7e70beeab8e311ae1d95256.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '73b2d3b461a8c80f185bbc90f4bb9db3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/eb10cda308b7111bdabe09efecf7f5f0.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '118b6e62c8079708c74b4dc0f18a0f24',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/365b7acf35a61018f77c21ff5df54903.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '156d200ea9dbaf6e61ad2a4faf7db602',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0e851fa57ff820ff79134556a179f08e.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '41f13543a44474602b7b9fff46e1001b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/72ef4a267758649d83ca349955afb4ac.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b16cc6c646134a5fa8b0a2778b1ff69f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ce05b561c24305ba398c799249b204de.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6f3080092d10cceb2bc1fcb255158cf8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/9e59723af244d315036f5707fbe388ba.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1516a8d7ba7f46b78446ffb195466921',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e3395ab90e8a72209b065a5245f3b272.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6053e432f43260641ec4434116f8e92b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b6c7ad3e01a3c2d2abd336f2576f4dc4.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '0d907de434ca21013290761ae2a58df2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/16c79ab8dca3bdd45e5fc0e003022591.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '72542f71206f1afe54c161dd85f2d3ba',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/fe7f2f653418bb2d3738392e27027085.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ff76450cb6a31f5fe56d817d014ab9db',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/5ca18ab5f562bd1dc6c09b093da11227.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c2121dc7c6e418b76967d6f4cca825e6',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/4c07e7036857bbbbcaa0179325ab5987.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b63ae5127e52f1251ffce69873c271d0',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/c45386af5d75fde34efefc31c62033db.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '91bb6bfc1f4f09959c5d83f5e9d2ec49',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/33abcd67dc3d9866d6d5432e83fcd78b.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'dbc9999cd5297ef1779c7e075c533583',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/8d938c83afd7b9f94787179efa53e8f3.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f2c743571a85967b5b2713c4a7942928',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/8ef8a0bd6cd0d16821bb79976a586223.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '83d8eeb37cc8fa59f9c1c22013b3ef84',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/455a39bf776d47a3cfc194413606383e.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'df9484f6a7d28a8aa034e616fd4f5723',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/7db30afa723a88e4fe76303cec9426c4.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9f020bb23eeb33348d17a9d060c904ea',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/3d94bcc91842e24909eed945c3c10566.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '502890743e5c2b0da0c65359e9ca9f3f',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/227e0ccaa1132c9ff6450cc4778327ba.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '615c3865eaad8f96c3f34f4573aef6cb',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/3ebe52967a7f5e81dedca95ebdd7751c.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '7fbf56f4dd478899355b6dd63535351b',
      'native_key' => 'web',
      'filename' => 'modContext/955c5d502465d963f167293c088d8d8f.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '4d71fdc564fc197168dedebadf11ddf0',
      'native_key' => 'mgr',
      'filename' => 'modContext/0eda2f168fc05e7425b2d4741402fd98.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a66acd06c2df9f38947629d8e7de1099',
      'native_key' => 'a66acd06c2df9f38947629d8e7de1099',
      'filename' => 'xPDOFileVehicle/97cb460ec0c0dc13252b29b32030a217.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '39a4c9b5ce6f3340039faada22cdb3f5',
      'native_key' => '39a4c9b5ce6f3340039faada22cdb3f5',
      'filename' => 'xPDOFileVehicle/25dabf1450ab609f0a5dc47ad04cafd3.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7faf62bd22a2fe7410cbaabec3d64e22',
      'native_key' => '7faf62bd22a2fe7410cbaabec3d64e22',
      'filename' => 'xPDOFileVehicle/d63f2630df5cd78505c0e5239627718e.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '16b6fbbf42562fd2704ec95e568bcb63',
      'native_key' => '16b6fbbf42562fd2704ec95e568bcb63',
      'filename' => 'xPDOFileVehicle/9dc965093c80a797df2c3f9b1ab03d3f.vehicle',
    ),
  ),
);