# MDL Theme

MODX 2.4 - with Material Design Lite (MDL) theme that lets you add a Material Design look and feel to your site. Row Listing and Grid Listing for resources plus a Contact Form. 
